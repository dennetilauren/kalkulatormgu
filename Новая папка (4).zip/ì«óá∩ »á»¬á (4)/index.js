let val1 = document.querySelector("#a1");
        let val2 = document.querySelector("#a2");
        let val3 = document.querySelector("#a3");
        let val4 = document.querySelector("#a4");
        let btn = document.querySelector("#calcButton")

        let vol

        btn.addEventListener("click", function () {
            // let ds = a1.value;
            // let adfa = a2.value;
            // let adfsaa = a3.value;
            // let aadfaa = a4.value;
            vol = Math.floor( 60000 * (val1.value * 0.004 + val2.value * 0.004 + val3.value * 0.004 + val4.value * 0.004) + 60000)
            document.querySelector("#output").textContent = vol + " Грн";
        });